package com.h4ll0.gamelauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFE0262E),
                    background = Color(0xFF0D0A0A),
                    surface = Color(0xFF191212)
                )
            ) { App() }
        }
    }
}

@Composable
fun App() {
    val c = LocalContext.current
    val prefs = remember { c.getSharedPreferences("gl", Context.MODE_PRIVATE) }
    fun load() = prefs.getString("fav", "")!!.lines().filter { it.contains("\t") }
        .map { it.split("\t", limit = 2).let { p -> p[0] to p[1] } }
    var favs by remember { mutableStateOf(load()) }
    fun save(l: List<Pair<String, String>>) {
        favs = l
        prefs.edit().putString("fav", l.joinToString("\n") { "${it.first}\t${it.second}" }).apply()
    }
    var name by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }
    fun toast(t: String) = Toast.makeText(c, t, Toast.LENGTH_SHORT).show()

    fun launch(t: String) {
        val s = t.trim()
        val uri = when {
            s.isNotEmpty() && s.all { it.isDigit() } -> "roblox://experiences/start?placeId=$s"
            s.startsWith("roblox://") || s.startsWith("https://www.roblox.com/") ||
                s.startsWith("https://roblox.com/") -> s
            else -> { toast("Isi Place ID (angka) atau link roblox.com"); return }
        }
        try {
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Roblox belum terpasang atau link tidak valid") }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Roblox Launcher", style = MaterialTheme.typography.headlineSmall)
            Text("Buka game lewat Place ID atau link. Tidak mengubah app Roblox.", color = Color.Gray)
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Nama game (opsional)") }, singleLine = true)
            OutlinedTextField(target, { target = it }, Modifier.fillMaxWidth(), label = { Text("Place ID / link private server") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { launch(target) }) { Text("Main") }
                OutlinedButton(onClick = {
                    if (target.isBlank()) toast("Isi Place ID / link dulu")
                    else { save(favs + ((name.ifBlank { target.trim() }) to target.trim())); name = ""; target = "" }
                }) { Text("Simpan favorit") }
                OutlinedButton(onClick = {
                    c.packageManager.getLaunchIntentForPackage("com.roblox.client")
                        ?.let { c.startActivity(it) } ?: toast("Roblox belum terpasang")
                }) { Text("Buka Roblox") }
            }
            Text("Favorit (${favs.size})", style = MaterialTheme.typography.titleMedium)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                items(favs) { f ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(f.first)
                                Text(f.second, color = Color.Gray, maxLines = 1)
                            }
                            Button(onClick = { launch(f.second) }) { Text("Main") }
                            TextButton(onClick = { save(favs - f) }) { Text("Hapus") }
                        }
                    }
                }
            }
        }
    }
}
